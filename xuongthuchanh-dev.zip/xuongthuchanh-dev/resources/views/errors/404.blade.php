@extends('layouts.master')

@section('content')
<div class="text-center">
    <img src="https://admiral.digital/wp-content/uploads/2023/08/404_page-not-found-1024x576.png" alt="404" class=" img-fluid">
</div>
@endsection


