<?php

namespace App\Http\Controllers;

use App\Models\Quiz;
use App\Models\Lesson;
use Illuminate\Http\Request;
use App\Models\Enrollment;
use Illuminate\Support\Facades\Auth;
use App\Models\UserQuizResult;

class QuizController extends Controller
{
    public function index()
    {
        $title = 'Quizzes';
        $quizzes = Quiz::with('lesson')->get();
        return view('admin.quizzes.index', compact('quizzes', 'title'));
    }

    public function create()
    {
        $title = 'Tạo quizz';
        $lessons = Lesson::all();
        return view('admin.quizzes.create', compact('lessons', 'title'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'lesson_id' => 'required|exists:lessons,id',
            'title' => 'required',
            'description' => 'nullable',
        ]);

        Quiz::create($request->all());
        return redirect()->route('admin.quizzes.index')->with('success', 'Quiz created successfully.');
    }

    public function show(Quiz $quiz)
    {
        $userId = Auth::check() ? Auth::id() : null;

        $lesson = $quiz->lesson; 
        $section = $lesson ? $lesson->section : null;
        $course = $section ? $section->course : null;

        $isEnrolled = false;
        if ($userId && $course) {
            $isEnrolled = Enrollment::where('user_id', $userId)
                ->where('course_id', $course->id)
                ->exists();
        }
        if ($isEnrolled) {
            $quiz->load([
                'questions.answers' => function ($query) {
                    $query->orderBy('is_correct', 'desc');
                }
            ]);
        }
        return view('showquizz', compact('quiz', 'isEnrolled', 'course'));
    }



    public function edit(Quiz $quiz)
    {
        $lessons = Lesson::all();
        return view('admin.quizzes.edit', compact('quiz', 'lessons'));
    }

    public function update(Request $request, Quiz $quiz)
    {
        $request->validate([
            'lesson_id' => 'required|exists:lessons,id',
            'title' => 'required',
            'description' => 'nullable',
        ]);

        $quiz->update($request->all());
        return redirect()->route('admin.quizzes.index')->with('success', 'Quiz updated successfully.');
    }

    public function destroy(Quiz $quiz)
    {
        $quiz->delete();
        return redirect()->route('admin.quizzes.index')->with('success', 'Quiz deleted successfully.');
    }
}
